const scene = document.getElementById("scene");
const replay = document.getElementById("replay");

replay.addEventListener("click", () => {
  scene.classList.add("restart");
  void scene.offsetWidth;
  scene.classList.remove("restart");
});
