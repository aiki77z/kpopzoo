# KPOPZOO Broccoli Intro Animation

这是从 ChatGPT 原型中拆出的独立可运行版本，供 Codex 直接读取和移植。

## 文件

- `index.html`：动画 DOM 结构
- `styles.css`：全部视觉和动画
- `script.js`：重播按钮
- `CODEX_PROMPT.txt`：给 Codex 的移植说明

## 预览

直接用浏览器打开 `index.html` 即可。

也可以运行：

```bash
python -m http.server 8000
```

然后访问本地 8000 端口。

## 本版本唯一文字修改

- 原圆形印章 `KZ / 2026` → `kpopzoo`
- 原纸片 `KPOPZOO archive 01` → `produced by broccoli`

除此之外动画结构、节奏、构图和其余文字保持原方案。

## 可替换位置

如果后面有真实西兰花 PNG/SVG，可以让 Codex 将：

```html
<div class="broccoli">🥦</div>
```

替换成图片元素，同时保留 `.broccoli` 的旋转动画类。

周围 `.photo` 当前是 CSS 抽象占位图，也可以后续替换成真实拼贴素材。
